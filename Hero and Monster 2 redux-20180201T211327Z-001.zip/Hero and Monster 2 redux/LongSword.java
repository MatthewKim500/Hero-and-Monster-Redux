public class LongSword extends Weapon
{
    public int damage = super.damage + 20;
}