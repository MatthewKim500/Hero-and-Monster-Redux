public class Armor{
    public String toString(){
        return "reduce attack damage by 1/3";
    }
}