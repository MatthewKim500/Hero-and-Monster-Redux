public class ShortSword extends Weapon
{
    public int damage = super.damage +10;
}