public class Weapon{
    public int damage = (int)Math.random() * 51 + 10;
}