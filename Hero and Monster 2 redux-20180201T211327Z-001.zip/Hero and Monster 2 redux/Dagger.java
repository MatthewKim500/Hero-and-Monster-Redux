public class Dagger extends Weapon
{
    public int damage = super.damage;
}